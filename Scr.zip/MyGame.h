#include <iostream>
#include"Player.h"
using namespace std;

class MyGame 
{
    string juego;
    string doc;

public:
    MyGame();
    void PrintTablero();
    void Start();
    void Start2();
    void Read(string);
    void Start3();

};