Arturo Alfaro Gonzalez
Rodrigo Aldahir Rosete Flores
German Wong del Toro
———— Instrucciones del serpientes y escaleras ————
1. Descarga los códigos
2. Inicia el código 
3. Selecciona el modo de Juego 
	3.1 El modo de juego 1 es manual
		3.1.1 Inicia el juego con “C”
		3.1.2 Es necesario poner los caracteres en mayúsculas
		3.1.3 Solo acepta los caracteres “C” y “E”
		3.1.4 Cuando quieras terminar el juego presiona “E”
	3.2 El modo de juego 2 es automático y te genera un .txt
		3.2.1 Con “C” agregas turnos
		3.2.2 Puedes agregar el número de turnos que desees 
		3.2.3 Es necesario poner los caracteres en mayúsculas
		3.2.4 Solo acepta los caracteres “C” y “E”
		3.2.5 Cuando quieras terminar el juego presiona “E”
		3.2.6 Cuando termines la secuencia se te arrojará un .TXT y 		      el juego correrá con tus valores
4. Simbología de cada letra: R-Ronda, J-Jugador, C-Casilla inicial, D-Dado, P-Tipo de casilla (N-Normal, S-Serpiente-3 y L-Escalera+3) y CA-Casilla actual.
