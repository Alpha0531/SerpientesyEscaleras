#include "Dice.h"


Dice::Dice(){
    caras = 0;
    
}

Dice::Dice(int caras){
    this-> caras = caras;
    
}

int Dice::lanzarDado()
{
    return 0;
}



























